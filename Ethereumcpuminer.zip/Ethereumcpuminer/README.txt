This application was made with Elicoin GUI Miner and xmrig.
Elicoin: https://github.com/elicoin/elicoin-gui-miner
xmrig: https://github.com/xmrig/xmrig

This application mines on the RandomX algo to https://www.unmineable.com/coins with only 0.75% fee! (miner also takes 1% fee)
To check how much you earned go to https://www.unmineable.com/coins/ETH/address and put in your ETH address.

To increase hashrate enable huge pages by running the program close it restart pc and then rerun it again this will increase the hashrate and will earn more!

Need help?
https://discord.gg/tkmFxxTPtF

*Donations:
BTC: 3GkfArNyXhbyjvNBKS8xgAztW4SNB9NrMf

ETH: 0x102533b16aa2ea21704e3fd0c549f69cf47d3011

LTC: MDTvpegc4BXvZNcHsGFLeQhjVwJCz4ksEC

DOGE: D6qG7kscB8fmsAAxvAKyarYYm6F83ZV46M

Happy Mining!